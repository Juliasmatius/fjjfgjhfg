import base64
import urllib.parse
import requests
print("IP of receiver")
ip = input("IP : ")
print("Port of receiver")
port = input("Port : ")
while True:
	stage_1 = input("Text to be sent : ")
	stage_7 = urllib.parse.quote(stage_1)
	try:
		requests.get("http://"+ip+":"+port+"/"+stage_7)
	except ConnectionRefusedError:
		print("Invalid ip or port (ConnectionRefusedError)")
		print("Please re-enter them")
		ip = input("IP : ")
		port = input("Port : ")