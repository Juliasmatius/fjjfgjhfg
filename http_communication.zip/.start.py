import os
os.system('start "Receiver" python3 receiver.py')
os.system('start "Sender" python3 sender.py')