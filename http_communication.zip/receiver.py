import os
from http.server import BaseHTTPRequestHandler, HTTPServer
import time
import base64
import urllib.parse
hostName = "localhost"
serverPort = int(input("Port : "))
os.system("cls")
class MyServer(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        path = self.path
        path = path.replace("/", "")
        path = urllib.parse.unquote(path)
        print(path)
if __name__ == "__main__":        
    webServer = HTTPServer(("", serverPort), MyServer)
    print("Server started http://%s:%s" % (hostName, serverPort))
    webServer.serve_forever()
    webServer.server_close()
    print("Server stopped.")